<?php
header('Content-Type: application/json;charset=UTF-8');
$conn = new mysqli('localhost','root','','relationship');
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$res = ['success'=>false,'message'=>''];

if ($action === 'add') {
  $f = trim($_POST['fullname']); 
  $rel = isset($_POST['relationship']) ? trim($_POST['relationship']) : 'Empty';
  $rel = $rel !== '' ? $rel : 'Empty';
  $job = isset($_POST['job']) ? trim($_POST['job']) : 'Empty';
  $job = $job !== '' ? $job : 'Empty';
  $phone = isset($_POST['phone']) ? trim($_POST['phone']) : 'Empty';
  $phone = $phone !== '' ? $phone : 'Empty';
  $birth = isset($_POST['birth']) ? trim($_POST['birth']) : 'xx/xx/xxxx';
  $birth = $birth !== '' ? $birth : 'xx/xx/xxxx';
  $addr = isset($_POST['address']) ? trim($_POST['address']) : 'Empty';
  $addr = $addr !== '' ? $addr : 'Empty';
  $last = isset($_POST['last_time_contact']) ? trim($_POST['last_time_contact']) : date("Y-m-d");
  $last = $last !== '' ? $last : date("Y-m-d");
  $note = isset($_POST['note']) ? trim($_POST['note']) : 'Empty';
  $note = $note !== '' ? $note : 'Empty';

  $stmt = $conn->prepare("INSERT INTO relationships (fullname,relationship,job,phone,birth,address,last_time_contact,note) VALUES(?,?,?,?,?,?,?,?)");
  $stmt->bind_param("ssssssss",$f,$rel,$job,$phone,$birth,$addr,$last,$note);
  if($stmt->execute()){ $res['success']=true;} else $res['message']='Insert lỗi';
  $stmt->close();
}

elseif ($action === 'update') {
  $f = isset($_POST['fullname']) ? trim($_POST['fullname']) : '';
  $rel = isset($_POST['relationship']) && trim($_POST['relationship']) !== '' ? trim($_POST['relationship']) : 'Empty';
  $job = isset($_POST['job']) && trim($_POST['job']) !== '' ? trim($_POST['job']) : 'Empty';
  $phone = isset($_POST['phone']) && trim($_POST['phone']) !== '' ? trim($_POST['phone']) : 'Empty';
  $birth = isset($_POST['birth']) && trim($_POST['birth']) !== '' ? trim($_POST['birth']) : 'xx/xx/xxxx';
  $addr = isset($_POST['address']) && trim($_POST['address']) !== '' ? trim($_POST['address']) : 'Empty';
  $last = isset($_POST['last_time_contact']) && trim($_POST['last_time_contact']) !== '' ? trim($_POST['last_time_contact']) : date("Y-m-d");
  $note = isset($_POST['note']) && trim($_POST['note']) !== '' ? trim($_POST['note']) : 'Empty';
  $stmt = $conn->prepare("UPDATE relationships SET relationship=?,job=?,phone=?,birth=?,address=?,last_time_contact=?,note=? WHERE fullname=?");
  $stmt->bind_param("ssssssss",$rel,$job,$phone,$birth,$addr,$last,$note,$f);
  if($stmt->execute()) $res['success']=true; else $res['message']='Update lỗi';
  $stmt->close();
}

elseif ($action === 'delete') {
  $f = $_POST['fullname'];
  $stmt = $conn->prepare("DELETE FROM relationships WHERE fullname=?"); $stmt->bind_param("s",$f);
  if($stmt->execute()) $res['success']=true; else $res['message']='Delete lỗi';
  $stmt->close();
}

elseif ($action === 'today') {
    $f = $_POST['fullname'];
    $today = date("Y-m-d");
    $stmt = $conn->prepare("UPDATE relationships SET last_time_contact=? WHERE fullname=?");
    $stmt->bind_param("ss", $today, $f);
    $res['success'] = $stmt->execute();
    $stmt->close();
}
  
$conn->close();
echo json_encode($res);
