<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8"/>
  <title>Quản Lý Mối Quan Hệ</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    html, body {
      height: 100%;
      margin: 0;
    }
  </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
  <div class="w-full min-h-screen bg-white p-4">
        <h1 class="text-2xl font-bold text-indigo-700 mb-6">Quản Lý Mối Quan Hệ</h1>

        <form id="addForm" class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <input type="hidden" name="action" value="add" />
        <div><label>Họ tên</label><input required name="fullname" class="w-full border p-2 rounded" /></div>
        <div><label>Mối quan hệ</label><input name="relationship" class="w-full border p-2 rounded" /></div>
        <div><label>Công việc</label><input name="job" class="w-full border p-2 rounded" /></div>
        <div><label>Số điện thoại</label><input name="phone" class="w-full border p-2 rounded" /></div>
        <div><label>Ngày sinh</label><input type="text" name="birth" class="w-full border p-2 rounded" placeholder="xx/xx/xxxx" /></div>
        <div><label>Địa chỉ</label><input name="address" class="w-full border p-2 rounded" /></div>
        <div><label>Lần liên hệ cuối</label><input type="date" name="last_time_contact" class="w-full border p-2 rounded" /></div>
        <div class="md:col-span-2"><label>Ghi chú</label><textarea name="note" class="w-full border p-2 rounded" rows="3"></textarea></div>
        <div class="md:col-span-2"><button class="bg-indigo-600 text-white px-4 py-2 rounded">Thêm</button></div>
        </form>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <input id="search_name" placeholder="Tìm theo tên..." class="p-2 border rounded" />
        <input id="search_relationship" placeholder="Tìm theo mối quan hệ..." class="p-2 border rounded" />
        </div>

        <div class="overflow-x-auto">
        <table class="min-w-full border">
            <thead class="bg-gray-100">
            <tr>
                <th class="p-2">Họ tên <button data-key="fullname" class="sort-btn">↕️</button></th>
                <th class="p-2">Mối quan hệ <button data-key="relationship" class="sort-btn">↕️</button></th>
                <th class="p-2">Công việc <button data-key="job" class="sort-btn">↕️</button></th>
                <th class="p-2">SĐT <button data-key="phone" class="sort-btn">↕️</button></th>
                <th class="p-2">
                    Ngày sinh
                    <button data-key="birth" class="sort-btn">↕️</button>
                    <button data-key="birth_upcoming" class="sort-btn" title="Sinh nhật gần">🎂</button>
                </th>
                <th class="p-2">Địa chỉ <button data-key="address" class="sort-btn">↕️</button></th>
                <th class="p-2">Liên hệ cuối <button data-key="last_time_contact" class="sort-btn">↕️</button></th>
                <th class="p-2">Ghi chú</th>
                <th class="p-2">Thao tác</th>
            </tr>
            </thead>
            <tbody id="dataTable"></tbody>
        </table>
        </div>
  </div>


  <script src="main.js"></script>
</body>
</html>
