function removeAccents(str) {
  return str.normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d").replace(/Đ/g, "d")
    .toLowerCase();
}

function tokenize(str) {
  return removeAccents(str).split(/\s+/).filter(Boolean);
}

let editingRow = null;
let currentFilters = { name: '', rel: '' };
let sortState = { key: null, asc: true };

function refreshTable() {
  $.getJSON('data.php', data => {
    if (data.success) {
      let rows = data.data;
      if (sortState.key) rows.sort(compareRows);
      renderTable(rows);
      applyFilters();
    } else alert('Không thể load dữ liệu');
  });
}

function renderTable(rows) {
  const tbody = $('#dataTable').empty();
  rows.forEach(r => {
    const tr = $('<tr>').attr('data-fullname', r.fullname).attr('data-relationship', r.relationship);
    ['fullname','relationship','job','phone','birth','address','last_time_contact','note'].forEach(k => {
      $('<td>').addClass('p-2').attr('data-key', k).text(r[k]).appendTo(tr);
    });
    const actions = $('<td>').addClass('p-2 flex gap-2');
    $('<button>').text('Sửa').addClass('text-blue-600').click(() => enableEditRow(tr)).appendTo(actions);
    $('<button>').text('Xoá').addClass('text-red-600').click(() => ajaxDelete(r.fullname)).appendTo(actions);
    $('<button>').text('Today').addClass('text-indigo-600').click(() => ajaxToday(r.fullname)).appendTo(actions);
    tr.append(actions);
    tbody.append(tr);
  });
}

function compareRows(a, b) {
  const key = sortState.key;
  if (!key) return 0;
  const emptyEnd = v => (v === 'Empty' || v === 'xx/xx/xxxx');
  let va = a[key], vb = b[key];

  if (key === 'birth_upcoming') {
    if (emptyEnd(a.birth)) return 1;
    if (emptyEnd(b.birth)) return -1;
    const distA = daysUntilNextBirthday(a.birth);
    const distB = daysUntilNextBirthday(b.birth);
    return sortState.asc ? distA - distB : distB - distA;
  }

  if (emptyEnd(va) && !emptyEnd(vb)) return 1;
  if (!emptyEnd(va) && emptyEnd(vb)) return -1;
  if (emptyEnd(va) && emptyEnd(vb)) return 0;

  if (key === 'birth') {
    const da = parseDateDMY(va), db = parseDateDMY(vb);
    return sortState.asc ? da - db : db - da;
  }

  if (key === 'last_time_contact') {
    const da = new Date(va), db = new Date(vb);
    return sortState.asc ? da - db : db - da;
  }

  va = va.toLowerCase(); vb = vb.toLowerCase();
  return sortState.asc ? va.localeCompare(vb) : vb.localeCompare(va);
}

function daysUntilNextBirthday(birthStr) {
  const [d, m] = birthStr.split('/').map(Number);
  if (!d || !m) return 9999;
  const today = new Date(), thisYear = today.getFullYear();
  let next = new Date(thisYear, m - 1, d);
  if (next < today) next.setFullYear(thisYear + 1);
  const diff = next - today;
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

function parseDateDMY(dmy) {
  const [d, m, y] = dmy.split('/').map(Number);
  return (!d || !m || !y) ? null : new Date(y, m - 1, d);
}

function setSort(key) {
  if (key === 'birth_upcoming') {
    sortState = { key: 'birth_upcoming', asc: true };
  } else if (sortState.key === key) {
    sortState.asc = !sortState.asc;
  } else {
    sortState = { key: key, asc: true };
  }
  refreshTable();
}

$('#search_name, #search_relationship').on('input', function() {
  currentFilters.name = removeAccents($('#search_name').val());
  currentFilters.rel = removeAccents($('#search_relationship').val());
  applyFilters();
});

function applyFilters() {
  const allRows = $('#dataTable tr').get();
  const exactMatches = [];
  const tokenMatches = [];

  const tokensName = tokenize($('#search_name').val());
  const tokensRel = tokenize($('#search_relationship').val());

  allRows.forEach(tr => {
    const fn = removeAccents($(tr).data('fullname'));
    const rl = removeAccents($(tr).data('relationship'));
    const exact = fn.includes(currentFilters.name) && rl.includes(currentFilters.rel);
    if (exact) exactMatches.push(tr);
    else {
      const nameOk = tokensName.every(tok => fn.includes(tok));
      const relOk = tokensRel.every(tok => rl.includes(tok));
      if (nameOk && relOk) tokenMatches.push(tr);
    }
  });

  $('#dataTable').empty().append(exactMatches).append(tokenMatches);
}

$('#addForm').on('submit', function(e) {
  e.preventDefault();
  $.ajax({
    url: 'api.php?action=add',
    method: 'POST',
    data: $(this).serialize(),
    dataType: 'json',
    success: res => {
      if (res.success) {
        $('#addForm')[0].reset();
        refreshTable();
      } else alert('Thêm lỗi: ' + res.message);
    }
  });
});
  
function enableEditRow(tr) {
  if (editingRow && editingRow[0] !== tr[0]) {
    alert('Bạn chỉ được chỉnh một dòng tại một thời điểm!');
    return;
  }

  editingRow = tr;
  const fullname = tr.data('fullname');
  const cache = {};

  tr.find('td[data-key]').each((i, td) => {
    const $td = $(td);
    const key = $td.data('key');
    if (key !== 'fullname') {
      const value = $td.text();
      cache[key] = value;
      const input = (key === 'note')
        ? $('<textarea>').addClass('w-full p-1 border rounded text-sm').attr('name', key).val(value)
        : $('<input>').addClass('w-full p-1 border rounded text-sm').attr('name', key).val(value);
      $td.empty().append(input);
    }
  });

  const actions = tr.find('td:last').empty();
  $('<button>').text('Save').addClass('text-green-600').click(() => ajaxUpdateRow(tr)).appendTo(actions);
  $('<button>').text('Cancel').addClass('text-gray-600').click(() => cancelEdit(tr, cache)).appendTo(actions);
}

function cancelEdit(tr, originalData) {
  tr.find('td[data-key]').each((i, td) => {
    const key = $(td).data('key');
    if (key !== 'fullname') {
      $(td).text(originalData[key]);
    }
  });

  const actions = tr.find('td:last').empty();
  const fullname = tr.data('fullname');
  $('<button>').text('Sửa').addClass('text-blue-600').click(() => enableEditRow(tr)).appendTo(actions);
  $('<button>').text('Xoá').addClass('text-red-600').click(() => ajaxDelete(fullname)).appendTo(actions);
  $('<button>').text('Today').addClass('text-indigo-600').click(() => ajaxToday(fullname)).appendTo(actions);

  editingRow = null;
}

function ajaxUpdateRow(tr) {
  const fullname = tr.data('fullname');
  const data = { action: 'update', fullname };

  tr.find('td[data-key]').each((i, td) => {
    const key = $(td).data('key');
    if (key !== 'fullname') {
      const val = $(td).find('input,textarea').val();
      data[key] = val;
    }
  });

  $.ajax({
    url: 'api.php?action=update',
    method: 'POST',
    data: data,
    dataType: 'json',
    success: function(res) {
      if (res.success) {
        editingRow = null;
        refreshTable();
      } else alert('Lỗi update: ' + res.message);
    }
  });
}

function ajaxDelete(fullname) {
  if (!confirm('Bạn chắc chắn muốn xoá?')) return;
  $.ajax({
    url: 'api.php?action=delete',
    method: 'POST',
    data: { action: 'delete', fullname },
    dataType: 'json',
    success: function(res) {
      if (res.success) refreshTable();
      else alert('Lỗi xoá: ' + res.message);
    }
  });
}

function ajaxToday(fullname) {
  $.ajax({
    url: 'api.php?action=today',
    method: 'POST',
    data: { action: 'today', fullname },
    dataType: 'json',
    success: function(res) {
      if (res.success) refreshTable();
      else alert('Lỗi cập nhật today: ' + res.message);
    }
  });
}

$(document).ready(() => {
  $('th .sort-btn').click(function() {
    setSort($(this).data('key'));
  });
  refreshTable();
});
