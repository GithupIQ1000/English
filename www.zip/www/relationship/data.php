<?php
header('Content-Type: application/json;charset=UTF-8');
$conn = new mysqli('localhost','root','','relationship');
$res = $conn->query("SELECT * FROM relationships ORDER BY fullname ASC");
$data = $res->fetch_all(MYSQLI_ASSOC);
$conn->close();
echo json_encode(['success'=>true, 'data'=>$data]);
