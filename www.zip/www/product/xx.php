<?php
$host = 'localhost';
$dbname = 'product';
$username = 'root';
$password = ''; 

$pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
]);  

// Đường dẫn file txt chứa dữ liệu
$txtFilePath = 'D:/x.txt';

// Đọc nội dung file
$fullTextContent = file_get_contents($txtFilePath);

// Tách từng dòng
$lines = preg_split('/\r\n|\r|\n/', $fullTextContent);


// Chuẩn bị câu lệnh insert và update giống file create_new_word.php
$sql_insert = "INSERT INTO goods (name)
               VALUES (?)";


// Câu lệnh kiểm tra từ, nghĩa, host đã tồn tại chưa
$sql_check_exist = "SELECT COUNT(*) FROM goods WHERE name = ?";

try {
    $pdo->beginTransaction();

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') continue;

        // Loại bỏ ký tự đầu dòng nếu có (• hoặc -)
        $line = preg_replace('/^[\•\-]\s*/u', '', $line);

        // Ở đây, chỉ lấy tên sản phẩm (name) từ mỗi dòng, không cần tách loại từ hay nghĩa
        $name = $line;

        // Kiểm tra sản phẩm đã tồn tại chưa
        $stmt_check = $pdo->prepare($sql_check_exist);
        $stmt_check->execute([$name]);
        $count = $stmt_check->fetchColumn();

        if ($count > 0) {
            echo "Sản phẩm '$name' đã tồn tại.<br>";
            continue;
        }

        // Nếu chưa tồn tại thì thêm mới
        $stmt_insert = $pdo->prepare($sql_insert);
        $stmt_insert->execute([$name]);
        echo "Sản phẩm '$name' đã được thêm mới.<br>";
    }
    $pdo->commit();
    echo "Đã import dữ liệu thành công!";
} catch (PDOException $e) {
    $pdo->rollBack();
    echo "Lỗi: " . htmlspecialchars($e->getMessage());
}
?>