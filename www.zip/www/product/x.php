<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Hiển thị JSON AI đẹp và dễ copy</title>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    #preview { max-width: 300px; margin-top: 10px; display: none; border: 1px solid #ccc; padding: 4px; }
    #fileInfo { margin-top: 10px; font-style: italic; color: #555; }
    .data-section {
        background: #f7f7f7;
        padding: 10px;
        border: 1px solid #ccc;
        margin-top: 10px;
        position: relative;
    }
    .copy-btn {
        position: absolute;
        top: 5px;
        right: 5px;
        padding: 5px 10px;
        background: #007bff;
        color: white;
        border: none;
        cursor: pointer;
        font-size: 12px;
        border-radius: 4px;
    }
    .copy-btn:hover { background: #0056b3; }
    .product-item {
        display: flex;
        gap: 5px;
        margin-top: 5px;
    }
    .product-part {
        flex: 1;
        border: 1px solid #ddd;
        padding: 5px;
        background: #fff;
        position: relative;
    }
    .copy-product {
        position: absolute;
        right: 5px;
        top: 5px;
        background: #28a745;
        color: white;
        border: none;
        padding: 2px 6px;
        font-size: 10px;
        border-radius: 3px;
        cursor: pointer;
    }
    .copy-product:hover { background: #1e7e34; }
</style>
</head>
<body>

<h2>📂 Tải ảnh hoặc PDF để AI phân tích</h2>
<input type="file" id="fileInput" accept="image/*,application/pdf">
<br>
<img id="preview" src="" alt="Xem trước ảnh">
<div id="fileInfo"></div>
<br><br>
<button id="sendBtn">🚀 Gửi file tới AI</button>

<h3>Kết quả AI trả về:</h3>
<div id="output"></div>

<script>
function copyText(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert("📋 Đã copy: " + text);
    });
}

// Hàm chuẩn hóa số: bỏ dấu "," trong input và đổi dấu thập phân "." -> ","
function formatNumber(numStr, isQuantity = false) {
    if (!numStr) return "";
    numStr = numStr.toString().trim().replace(/,/g, ""); // bỏ dấu phẩy trong chuỗi gốc
    let num = parseFloat(numStr);
    if (isNaN(num)) return numStr;

    if (isQuantity) {
        // Số lượng: nếu là số nguyên thì trả nguyên, nếu có thập phân thì dùng dấu ","
        return num % 1 === 0 ? num.toString() : num.toString().replace(".", ",");
    }

    // Đơn giá: luôn giữ 2 số thập phân và đổi dấu "." thành ","
    return num.toFixed(2).replace(".", ",");
}



function renderData(jsonData) {
    let html = "";

    if (jsonData["Chủ đề"]) {
        html += `<div class="data-section">
                    <strong>Chủ đề:</strong> ${jsonData["Chủ đề"]}
                 </div>`;
    }

    if (jsonData["Số đơn vận"]) {
        html += `<div class="data-section">
                    <strong>Số đơn vận:</strong> ${jsonData["Số đơn vận"]}
                 </div>`;
    }

    if (Array.isArray(jsonData["Sản phẩm"])) {
        html += `<div class="data-section">
                    <strong>Sản phẩm:</strong>`;
        jsonData["Sản phẩm"].forEach((sp) => {
            let tenSP = sp[0] || "";
            let sl = formatNumber(sp[1]);
            let gia = formatNumber(sp[2]);

            html += `<div class="product-item">
                        <div class="product-part">${tenSP}
                        </div>
                        <div class="product-part">${sl}
                        </div>
                        <div class="product-part">${gia}
                        </div>
                     </div>`;
        });
        html += `</div>`;
    }

    $("#output").html(html);
}

function request_AI(base64Data, mimeType) {
    var api_key = "AIzaSyB1jQP2jxowOUKiuvTGGAqlzqGK_-ZoiFA";

    var prompt = "Trong file sau là nhập hàng từ các nhà phân phối CNC, CN Bảo Long, Hải Yến, Minh Hạnh, Gia Phước. Số lượng: only number, exclude other characters. Đơn giá: only number and ',' take 2 units after decimal point, exclude other characters ";
    prompt += "Hãy chọn một trong các nhà phân phối trên dựa trên nội dung và trả về các dữ liệu với định dạng chính xác như sau:\n";
    prompt += '{ "Chủ đề": "Hải Yến số BH131758 ngày 11/12/2007"(ghi đầy đủ như mô tả gồm "Hải Yến", "ngày", không ghi "số phiếu" mà phải ghi là "số"), "Số đơn vận": "12215"(có hoặc không), "Sản phẩm": [["Adapter Dell 19.5V - 4.62A chân to kim nhỏ Zin","2"(số lượng),"140000.00"(đơn giá)],...]}';
    var url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + api_key;

    var data = {
        "contents": [
            {
                "parts": [
                    { "text": prompt },
                    { "inline_data": { "mime_type": mimeType, "data": base64Data.split(",")[1] } }
                ]
            }
        ]
    };

    $.ajax({
        url: url,
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(data),
        success: function (response) {
            try {
                var rawText = response.candidates?.[0]?.content?.parts?.[0]?.text || "";
                rawText = rawText.trim();
                rawText = rawText.replace(/^```(json)?\s*/i, "");   
                rawText = rawText.replace(/\s*```$/g, "");          
                let firstCurly = rawText.indexOf('{');
                if (firstCurly !== -1) {
                    rawText = rawText.slice(firstCurly);
                }
                var sentences = JSON.parse(rawText);
                renderData(sentences);
            } catch (e) {
                console.error("❌ Lỗi xử lý JSON:", e);
                alert("Gemini trả về định dạng không đúng JSON.");
            }
        },
        error: function (err) {
            console.error("❌ Lỗi gửi request:", err);
            alert("Lỗi khi gọi API Gemini.");
        }
    });
}

$("#fileInput").on("change", function(e) {
    var file = e.target.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function(evt) {
        var mimeType = file.type;
        if (mimeType.startsWith("image/")) {
            $("#preview").attr("src", evt.target.result).show();
            $("#fileInfo").text("");
        } else {
            $("#preview").hide();
            $("#fileInfo").text("📄 File PDF: " + file.name);
        }
    };
    reader.readAsDataURL(file);
});

$("#sendBtn").on("click", function() {
    var file = $("#fileInput")[0].files[0];
    if (!file) {
        alert("Vui lòng chọn file trước.");
        return;
    }
    var reader = new FileReader();
    reader.onload = function(evt) {
        request_AI(evt.target.result, file.type);
    };
    reader.readAsDataURL(file);
});
</script>

</body>
</html>
