<?php
// ======== KẾT NỐI DATABASE ========
$host = "127.0.0.1";
$dbname = "product";
$username = "root";
$password = ""; // sửa nếu bạn có mật khẩu MySQL

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Lấy tất cả sản phẩm
    $stmt = $pdo->query("SELECT name FROM goods");
    $products = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    die("Kết nối thất bại: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tìm kiếm sản phẩm</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        input { padding: 10px; width: 100%; margin-bottom: 15px; font-size: 16px; box-sizing: border-box; }
        ul { list-style: none; padding: 0; }
        li { padding: 5px 0; border-bottom: 1px solid #ccc; }
        .highlight { background-color: yellow; }
        .pagination { margin-top: 10px; }
        .pagination button { padding: 5px 10px; margin: 0 5px; }
    </style>
</head>
<body>
    <h2>Tìm kiếm sản phẩm</h2>
    <input type="text" id="searchBox" placeholder="Nhập tên sản phẩm...">
    <ul id="productList"></ul>
    <div class="pagination">
        <button id="prevBtn">&lt;</button>
        <span id="pageInfo"></span>
        <button id="nextBtn">&gt;</button>
    </div>

    <script>
        // ====== DỮ LIỆU TỪ PHP ======
        const products = <?php echo json_encode($products, JSON_UNESCAPED_UNICODE); ?>;

        const listEl = document.getElementById('productList');
        const searchEl = document.getElementById('searchBox');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const pageInfo = document.getElementById('pageInfo');

        let currentPage = 1;
        const itemsPerPage = 100;
        let filteredProducts = [...products];
        let searchTimeout = null;

        function paginateData(data) {
            const start = (currentPage - 1) * itemsPerPage;
            return data.slice(start, start + itemsPerPage);
        }

        function updatePageInfo() {
            const totalPages = Math.ceil(filteredProducts.length / itemsPerPage) || 1;
            pageInfo.textContent = `Trang ${currentPage} / ${totalPages}`;
            prevBtn.disabled = currentPage <= 1;
            nextBtn.disabled = currentPage >= totalPages;
        }

        function renderList(arr, tokens = []) {
            listEl.innerHTML = '';
            arr.forEach(name => {
                let displayName = name;
                tokens.forEach(t => {
                    const regex = new RegExp(`(${t})`, 'gi');
                    displayName = displayName.replace(regex, '<span class="highlight">$1</span>');
                });
                listEl.innerHTML += `<li>${displayName}</li>`;
            });
        }

        function levenshtein(a, b) {
            const matrix = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
            for (let i = 0; i <= a.length; i++) matrix[i][0] = i;
            for (let j = 0; j <= b.length; j++) matrix[0][j] = j;
            for (let i = 1; i <= a.length; i++) {
                for (let j = 1; j <= b.length; j++) {
                    const cost = a[i - 1] === b[j - 1] ? 0 : 1;
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j] + 1,
                        matrix[i][j - 1] + 1,
                        matrix[i - 1][j - 1] + cost
                    );
                }
            }
            return matrix[a.length][b.length];
        }

        function searchProducts(rawQuery) {
            // Lọc ký tự ngoài chữ và số thành khoảng trắng
            const query = rawQuery.replace(/[^a-zA-Z0-9À-ỹà-ỹ]/g, " ").trim().toLowerCase();

            if (!query) {
                filteredProducts = [...products];
                currentPage = 1;
                renderList(paginateData(filteredProducts));
                updatePageInfo();
                return;
            }

            const tokens = query.split(/\s+/).filter(Boolean);
            const scored = products.map(product => {
                const nameLower = product.toLowerCase();
                let matchScore = 0;
                tokens.forEach(token => {
                    if (nameLower.includes(token)) {
                        matchScore += token.length * 2;
                    } else {
                        const words = nameLower.split(/\s+/);
                        let bestDist = Infinity;
                        words.forEach(w => {
                            const dist = levenshtein(token, w);
                            if (dist < bestDist) bestDist = dist;
                        });
                        const maxLen = Math.max(token.length, ...words.map(w => w.length));
                        const similarity = 1 - bestDist / maxLen;
                        if (similarity > 0.5) {
                            matchScore += similarity * token.length;
                        }
                    }
                });
                return { name: product, score: matchScore };
            });

            scored.sort((a, b) => b.score - a.score);
            filteredProducts = scored.filter(item => item.score > 0).map(item => item.name);
            currentPage = 1;
            renderList(paginateData(filteredProducts), tokens);
            updatePageInfo();
        }

        // Sự kiện tìm kiếm có debounce 1 giây
        searchEl.addEventListener('input', function () {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                searchProducts(this.value);
            }, 1000);
        });

        prevBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                renderList(paginateData(filteredProducts));
                updatePageInfo();
            }
        });

        nextBtn.addEventListener('click', () => {
            const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                renderList(paginateData(filteredProducts));
                updatePageInfo();
            }
        });

        // Hiển thị mặc định trang đầu
        renderList(paginateData(filteredProducts));
        updatePageInfo();
    </script>
</body>
</html>
