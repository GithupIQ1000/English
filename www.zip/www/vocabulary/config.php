<?php
$currentDir = str_replace('\\', '/', __DIR__);
$documentRoot = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
if ($currentDir !== $documentRoot) {
    $relativePath = str_replace($documentRoot, '', $currentDir);
    if (substr($relativePath, 0, 7) === '/htdocs') {
        $relativePath = explode('/', $relativePath)[1];
        $basePath = $documentRoot . '/' . $relativePath;
    } else {
        $basePath = $documentRoot;
    }
} else {
    $basePath = $documentRoot;
}
require_once $basePath . '/config.php';


define('ROOT_PATH', __DIR__);

$relative_path_from_doc_root = str_replace(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '', str_replace('\\', '/', __DIR__));
define('BASE_URL', rtrim($relative_path_from_doc_root, '/'));
?>