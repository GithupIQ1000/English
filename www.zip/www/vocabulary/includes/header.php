<?php 
include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/functions.php';
if (empty($_SESSION['user'])) {
    header("Location: /vocabulary/accounts/index.php");
    die();
}
?>
<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/vocabulary/includes/functions.js"></script>
</head>
<body>