function hideMessageAfterDelay() {
    setTimeout(function() {
        var element = document.getElementById("3s_hide");
        if (element) {
            element.style.transition = "opacity 1s ease";
            element.style.opacity = 0;
            setTimeout(() => { element.style.display = "none"; }, 1000);
        }
    }, 3000);
}
