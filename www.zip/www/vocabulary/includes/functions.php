<?php 
include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/config/database.php';
session_start();
?>