<?php
include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/functions.php';
header('Content-Type: application/json');

if ($_POST['type'] == 'word') {
    $type = 'word';
} else if ($_POST['type'] == 'reading') {
    $type = 'reading';
} else if ($_POST['type'] == 'speaking') {
    $type = 'speaking';
}

if (empty($_POST['words'])) {
    $data = date('Y/m/d');
    try {
        $stmt = $pdo->prepare("SELECT word, type, mean, sum_point_{$type} FROM words WHERE next_{$type}_time <= ? AND check_{$type} AND host = ? ORDER BY sum_point_{$type} ASC LIMIT 80");
        $stmt->execute([$data, $_SESSION['user']['username']]);
        $words = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(array('success' => true, 'message' => $words));
    } catch (PDOException $e) {
        echo json_encode(array('success' => false, 'message' => "Lỗi truy vấn: " . htmlspecialchars($e->getMessage())));
    }
} else{
    $stmt = $pdo->prepare("SELECT point_jump_word, point_jump_meaning, point_jump_reading, Nx_points FROM users WHERE username = ?");
    $stmt->execute([$_SESSION['user']['username']]);
    $setting = $stmt->fetch(PDO::FETCH_ASSOC);

    $words = $_POST['words'];
    foreach ($words as $word) {
        $data = new DateTime();
        $point = $word['sum_point_' . $type];
        if ($word['status'] == -1) { continue;}
        if ($word['status'] == 1) {
            if ($type == 'word') {
                $Bonus_point = $setting['point_jump_word'] + round($point/6, 2) + rand(-9, 9)/100;
            } else if ($type == 'meaning') {
                $Bonus_point = $setting['point_jump_meaning'] + round($point/6, 2) + rand(-9, 9)/100;
            } else if ($type == 'reading') {
                $Bonus_point = $setting['point_jump_reading'] + round($point/6, 2) + rand(-9, 9)/100;
            }
            $point += $Bonus_point;
            if ($word['Nx_points'] && $point < 45){
                $point = round($point*$setting['Nx_points'], 2);
            }else if($word['Nx_points']){
                $point += round($point/6*$setting['Nx_points'], 2);
            }
            $data->add(new DateInterval('P' . (int)$point . 'D'));
        } else if ($word['status'] == 0) {
            $point = round($point*2/3, 2);
            if ($word['Nx_points']){
                $point = round($point/$setting['Nx_points'], 2);
            }
            $data->add(new DateInterval('P' . (int)($point/2) . 'D'));
        }
        try {
            $stmt = $pdo->prepare("UPDATE words SET next_{$type}_time = ?, sum_point_{$type} = ? WHERE word = ? AND type = ? AND mean = ?");
            $stmt->execute([$data->format('Y-m-d'), $point, $word['word'], $word['type'], $word['mean']]);
        } catch (PDOException $e) {
            echo json_encode(array('success' => false, 'message' => "Lỗi cập nhật: " . htmlspecialchars($e->getMessage())));
            die();
        }
    }   
    echo json_encode(array('success' => true, 'message' => "Cập nhật thành công"));
}
?>