<?php
include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/functions.php';
header('Content-Type: application/json');

// Lấy dữ liệu từ form
$new_word = strtolower(trim($_POST['new-word']));
$type = strtolower(trim($_POST['type']));
$mean = mb_strtolower(trim($_POST['mean']), 'UTF-8');

$check_word = isset($_POST['check-word']) ? 1 : 0;
$check_reading = isset($_POST['check-reading']) ? 1 : 0;
$check_speaking = isset($_POST['check-speaking']) ? 1 : 0;

$host = $_SESSION['user']['username'];

$today = date('Y-m-d');

$sql_insert = "INSERT INTO words (word, type, mean, check_word, check_reading, check_speaking, sum_point_word, sum_point_reading, sum_point_speaking, next_word_time, next_reading_time, next_speaking_time, host)
               VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?, ?, ?)";

$sql_update = "UPDATE users_convenience SET blank_check_word = ?, blank_check_reading = ?, blank_check_speaking = ? WHERE host = ?";

try {
    $pdo->beginTransaction();

    $stmt_insert = $pdo->prepare($sql_insert);
    $result_insert = $stmt_insert->execute([
        $new_word, $type, $mean, $check_word, $check_reading, $check_speaking,
        $today, $today, $today, $host
    ]);

    $stmt_update = $pdo->prepare($sql_update);
    $result_update = $stmt_update->execute([
        $check_word, $check_reading, $check_speaking, $host
    ]);

    if ($result_insert && $result_update) {
        $pdo->commit();
        echo json_encode(array("message" => "<div id='3s_hide' style='font-size: 24px; color: green;'>Đã tạo từ: $new_word ($type): $mean</div>"));
    } else {
        $pdo->rollBack();
        echo json_encode(array("message" => "<div id='3s_hide' style='font-size: 24px; color: red;'>Có lỗi khi tạo từ mới.</div>"));
    }
} catch (PDOException $e) {
    $pdo->rollBack();
    if ($e->getCode() == 23000) { // Lỗi trùng khoá chính
        echo json_encode(array("message" => "<div id='3s_hide' style='font-size: 24px; color: red;'>Từ này đã có trong từ điển</div>"));
    } else {
        echo json_encode(array("message" => "<div id='3s_hide' style='font-size: 24px; color: red;'>" . htmlspecialchars($e->getMessage()) . "</div>"));
    }
}

$stmt = null; 
?>