<?php
include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/functions.php';
header('Content-Type: application/json');

$username = $_SESSION['user']['username'];

if ($_POST['type'] == 'blank') {
    try {
        $stmt = $pdo->prepare("SELECT blank_check_word, blank_check_reading, blank_check_speaking FROM users_convenience WHERE host = ?");
        $stmt->execute([$username]);
        $blanks = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'message' => $blanks]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Lỗi truy vấn: ' . htmlspecialchars($e->getMessage())]);
    }
    exit;
} else if ($_POST['type'] == 'setting') {
    if (isset($_POST['point_jump_word']) && isset($_POST['point_jump_reading']) && isset($_POST['point_jump_speaking']) && isset($_POST['Nx_point'])) {
        $point_jump_word = floatval($_POST['point_jump_word']);
        $point_jump_reading = floatval($_POST['point_jump_reading']);
        $point_jump_speaking = floatval($_POST['point_jump_speaking']);
        $Nx_points = floatval($_POST['Nx_point']);

        try {
            $stmt = $pdo->prepare("UPDATE users SET point_jump_word = ?, point_jump_reading = ?, point_jump_speaking = ?, Nx_points = ? WHERE username = ?");
            $stmt->execute([$point_jump_word, $point_jump_reading, $point_jump_speaking, $Nx_points, $username]);
            echo json_encode(['success' => true, 'message' => 'Lưu cài đặt thành công!']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Lỗi lưu cài đặt: ' . htmlspecialchars($e->getMessage())]);
        }
        exit;
    } else {
        try {
            $stmt = $pdo->prepare("SELECT point_jump_word, point_jump_reading, point_jump_speaking, Nx_points FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $setting = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($setting) {
                echo json_encode(['success' => true, 'message' => $setting]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Không tìm thấy cài đặt người dùng.']);
            }
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Lỗi truy vấn: ' . htmlspecialchars($e->getMessage())]);
        }
        exit;
    }
}