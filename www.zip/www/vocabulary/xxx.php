
<!-- <?php
// Kết nối database sử dụng PDO giống file create_new_word.php
include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/functions.php';

$today = date('Y-m-d');

// Truy vấn cập nhật sum_point_reading và next_reading_time cho các bản ghi thỏa điều kiện
$sql_update = "UPDATE words SET sum_point_reading = 0, next_reading_time = :today WHERE sum_point_reading <= 10";

$stmt = $pdo->prepare($sql_update);
$stmt->execute([':today' => $today]);
echo "Từ '$new_word' với nghĩa '$mean' đã được thêm mới.<br>";

?> -->




<!-- <?php
// Đường dẫn file txt chứa dữ liệu
$txtFilePath = 'D:\Documents/x.txt';

// Đọc nội dung file
$fullTextContent = file_get_contents($txtFilePath);

// Tách từng dòng
$lines = preg_split('/\r\n|\r|\n/', $fullTextContent);

// Kết nối database sử dụng PDO giống file create_new_word.php
include $_SERVER['DOCUMENT_ROOT'] . '/includes/functions.php';

$host = $_SESSION['user']['username'];
$today = date('Y-m-d');

// Chuẩn bị câu lệnh insert và update giống file create_new_word.php
$sql_insert = "INSERT INTO words (word, type, mean, check_word, check_meaning, check_reading, sum_point_word, sum_point_meaning, sum_point_reading, next_word_time, next_meaning_time, next_reading_time, host)
               VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?, ?, ?)";


// Câu lệnh kiểm tra từ, nghĩa, host đã tồn tại chưa
$sql_check_exist = "SELECT COUNT(*) FROM words WHERE word = ? AND mean = ? AND host = ?";

try {
    $pdo->beginTransaction();

    // Mặc định các trường check là 0
    $check_word = 1;
    $check_meaning = 1;
    $check_reading = 1;

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') continue;

        // Loại bỏ ký tự đầu dòng nếu có (• hoặc -)
        $line = preg_replace('/^[\•\-]\s*/u', '', $line);

        // Tách từ, loại từ và nghĩa
        if (preg_match('/^(.+?)\s*\((.+?)\):\s*(.+)$/u', $line, $matches)) {
            $new_word = strtolower(trim($matches[1]));
            $type = strtolower(trim($matches[2]));
            $mean = strtolower(trim($matches[3]));

            // Kiểm tra từ, nghĩa, host đã tồn tại chưa
            $stmt_check = $pdo->prepare($sql_check_exist);
            $stmt_check->execute([$new_word, $mean, $host]);
            $count = $stmt_check->fetchColumn();

            if ($count > 0) {
                echo "Từ '$new_word' với nghĩa '$mean' đã tồn tại.<br>";
                continue;
            }

            // Nếu chưa tồn tại đúng word, mean, host, thì thêm mới (cho phép nhiều nghĩa cho 1 từ)
            $stmt_insert = $pdo->prepare($sql_insert);
            $stmt_insert->execute([
                $new_word, $type, $mean, $check_word, $check_meaning, $check_reading,
                $today, $today, $today, $host
            ]);
            echo "Từ '$new_word' với nghĩa '$mean' đã được thêm mới.<br>";
        }
    }
    $pdo->commit();
    echo "Đã import dữ liệu thành công!";
} catch (PDOException $e) {
    $pdo->rollBack();
    echo "Lỗi: " . htmlspecialchars($e->getMessage());
}
?> -->