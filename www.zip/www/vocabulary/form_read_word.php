<?php include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/header.php';?>
<div style="display: flex; flex-direction: column; gap: 10px; align-items: center; justify-content: center; height: 100vh;">
    <div id="word" style="display: flex; align-items: center; justify-content: center;"></div>
    <div id="answer" style="display: flex; flex-direction: column; align-items: center; justify-content: center;"></div>
    <div style="display: flex; gap: 10px; justify-content: center;">
        <button class="learn" type="button" onclick="nextWord()" style="font-size: 24px; padding: 10px 20px;">Next</button>
        <button class="learn" type="button" onclick="backWord()" style="font-size: 24px; padding: 10px 20px;">Back</button>
    </div>
    <button 
        onclick="if(confirm('Bạn có chắc chắn muốn quay lại trang chủ?')) { window.location.href='/index.php'; } else { alert('Hành động đã bị hủy bỏ!'); }" 
        style="font-size: 24px; padding: 10px 20px; margin-top: 10px;">Quay lại
    </button>
</div>
<script>
    $(document).ready(function() {
        takeVocabulary();
    });

    function takeVocabulary() {
        $.ajax({
            url: '/vocabulary/process/vocabulary.php',
            method: 'POST',
            data: {type: 'reading'},
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    if (data.message.length > 0) {
                        count = -1;
                        end_count = data.message.length;
                        words = data.message;
                        nextWord();
                    } else {
                        $('.learn').hide();
                        $('#word').html('<div style="font-size: 30px;">Hôm nay không có readings nào.</div>');
                    }
                } else {
                    alert(data.message);
                }
            },
            error: function(error) {
                console.error('Lỗi:', error);
            }
        });
    }

    function nextWord() {
        count++;
        if (count < end_count) {
            if (typeof words[count]['status'] == 'undefined') {
                words[count]['status'] = -1;
            }
            if (words[count]['status'] == -1) {
                words[count]['Nx_points'] = 0;
                $('#answer').html('<button type="button" onclick="Nx_points()" style="font-size: 24px; padding: 10px 20px;">x N_point</button>');
            } else {
                $('#answer').html(`
                    <div style="display: flex; gap: 10px; align-items: center; justify-content: center;">
                        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center;">
                            <div id="sentence" style="font-size: 30px;">${words[count].word}</div>
                            <div style="font-size: 30px;">${words[count].word} (${words[count].type}): ${words[count].mean}</div>
                        </div>
                        <div style="display: flex; gap: 10px; justify-content: center;">
                            <button type="button" onclick="mark(1)" style="font-size: 24px; padding: 10px 20px;">Ok</button>
                            <button type="button" onclick="mark(0)" style="font-size: 24px; padding: 10px 20px;">Forget</button>
                        </div>
                    </div>
                `);
            }
            $('#word').html('<div id="sentence" style="font-size: 35px; color: ' + (words[count].status === 0 ? 'red' : (words[count].status === 1 ? 'green' : 'black')) + '; padding: 10px;">' + words[count].word + '</div>' +
            '<button type="button" onclick="answer()" style="font-size: 24px; padding: 10px 20px;">Answer</button>');
        } else {
            count = end_count;
            $('#word').html('<div style="font-size: 30px;">Bạn đã hoàn thành readings ngày hôm nay </div>' +
            '<button type="button" onclick="saveVocabulary()" style="font-size: 24px; padding: 10px 20px;  margin: 10px">Finish</button>');
            $('#answer').html('');
        }
    }

    function backWord() {
        count--;
        if (count >= 0) {            if (words[count]['status'] == -1) {
                words[count]['Nx_points'] = 0;
                $('#answer').html('<button type="button" onclick="Nx_points()" style="font-size: 24px; padding: 10px 20px;">x N_point</button>');
            } else {
                $('#answer').html(`
                    <div style="display: flex; gap: 10px; align-items: center; justify-content: center;">
                        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center;">
                            <div id="sentence" style="font-size: 30px;">${words[count].word}</div>
                            <div style="font-size: 30px;">${words[count].word} (${words[count].type}): ${words[count].mean}</div>
                        </div>
                        <div style="display: flex; gap: 10px; justify-content: center;">
                            <button type="button" onclick="mark(1)" style="font-size: 24px; padding: 10px 20px;">Ok</button>
                            <button type="button" onclick="mark(0)" style="font-size: 24px; padding: 10px 20px;">Forget</button>
                        </div>
                    </div>
                `);
            }
            $('#word').html('<div id="sentence" style="font-size: 35px; color: ' + (words[count].status === 0 ? 'red' : (words[count].status === 1 ? 'green' : 'black')) + '; padding: 10px;">' + words[count].word + '</div>' +
            '<button type="button" onclick="answer()" style="font-size: 24px; padding: 10px 20px;">Answer</button>');
        } else {
            count = 0;
        }   
    }

    function Nx_points() {
        words[count]['Nx_points'] = 1;
        $('#answer').html('');
    }

    function answer() {
        var html = `<div style="font-size: 35px;">(${words[count].type})</div>`;
        if ($('#answer').html() === '' || $('#answer').html() ==='<button type="button" onclick="Nx_points()" style="font-size: 24px; padding: 10px 20px;">x N_point</button>') {
            $('#answer').html(html);
        } else if ($('#answer').html().trim() === html.trim()){
            $('#answer').html(`
                <div style="display: flex; gap: 10px; align-items: center; justify-content: center;">
                    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center;">
                        <div id="sentence" style="font-size: 30px;">${words[count].word}</div>
                        <div style="font-size: 30px;">${words[count].word} (${words[count].type}): ${words[count].mean}</div>
                    </div>
                    <div style="display: flex; gap: 10px; justify-content: center;">
                        <button type="button" onclick="mark(1)" style="font-size: 24px; padding: 10px 20px;">Ok</button>
                        <button type="button" onclick="mark(0)" style="font-size: 24px; padding: 10px 20px;">Forget</button>
                    </div>
                </div>
            `);
        }else{
            $('#answer').html('');
        }
    }

    function mark(status) {
        words[count]['status'] = status;
        if (status) {
            $('#sentence').css('color', 'green');
            setTimeout(function() {
                nextWord();
            }, 1000);
        } else {
            $('#sentence').css('color', 'red');
        }
    }

    function saveVocabulary() {
        $.ajax({
            url: '/vocabulary/process/vocabulary.php',
            method: 'POST',
            data: {type: 'reading', words: words},
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    alert(data.message);
                } else {
                    alert(data.message);
                }
            },
            error: function(error) {
                console.error('Lỗi:', error);
            }
        });

        $('.learn').hide();
        $('#word').html('<div id="finish" style="font-size: 30px; max-height: 80vh; overflow-y: auto; padding: 10px; background-color: #fff; border-radius: 8px;">Bạn đã hoàn thành readings ngày hôm nay </div>');
        $('#answer').html('');
        words.forEach(function(word) {
            if (word.status == 1 || word.status == 0) {
                $('#finish').append('<div style="font-size: 30px; color: ' + (word.status === 0 ? 'red' : (word.status === 1 ? 'green' : 'black')) + ';">' + word.word + ' (' + word.type + '): ' + word.mean + '</div>');
            }
        });
    }
</script>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/footer.php';?>