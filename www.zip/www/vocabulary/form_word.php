<?php include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/header.php';?>
<div style="display: flex; flex-direction: column; gap: 10px; align-items: center; justify-content: center; height: 100vh;">
    <div id="vocabulary" style="display: flex; align-items: center; justify-content: center;"></div>
    <div style="display: flex; gap: 10px; justify-content: center;">
        <button class="learn" type="button" onclick="next_vocabulary()" style="font-size: 24px; padding: 10px 20px;">Next</button>
        <button class="learn" type="button" onclick="back_vocabulary()" style="font-size: 24px; padding: 10px 20px;">Back</button>
    </div>
    <button 
        onclick="if(confirm('Bạn có chắc chắn muốn quay lại trang chủ?')) { window.location.href='/vocabulary/index.php'; } else { alert('Hành động đã bị hủy bỏ!'); }" 
        style="font-size: 24px; padding: 10px 20px; margin-top: 10px;">Quay lại
    </button>
</div>
<script>
    $(document).ready(function() {
        vocabulary();
    });

    function vocabulary() {
        $.ajax({
            url: '/vocabulary/process/vocabulary.php',
            method: 'POST',
            data: {type: 'word'},
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    if (data.message.length > 0) {
                        count = -1;
                        end_count = data.message.length;
                        words = data.message;
                        next_vocabulary();
                    } else {
                        $('.learn').hide();
                        $('#vocabulary').html('<div style="font-size: 30px;">Hôm nay không có words nào.</div>');
                    }
                } else {
                    alert(data.message);
                }
            },
            error: function(error) {
                console.error('Lỗi:', error);
            }
        });
    }

    function next_vocabulary() {
        count++;
        if (count < end_count) {
            if (typeof words[count]['status'] == 'undefined') { words[count]['status'] = -1; words[count]['temporary'] = ""; }
            
            $('#vocabulary').html('<div style="font-size: 35px;">' + words[count].mean + ' ('+ words[count].type + '):' + '</div>' +
            '<input id="word" placeholder="Nhập từ" required style="font-size: 30px; border: 2px solid #333; padding: 10px; width: 300px; margin: 10px; font-weight: bold; color: ' + (words[count].status === 0 ? 'red' : (words[count].status === 1 ? 'green' : 'black')) + ';">' +
            '<button type="button" onclick="submit()" style="font-size: 24px; padding: 10px 20px;">Submit</button>');

            if (words[count].temporary != "") {
                $('#word').val(words[count].temporary);
            }
        } else {
            count = end_count;
            $('#vocabulary').html('<div style="font-size: 30px;">Bạn đã hoàn thành words ngày hôm nay </div>' +
            '<button type="button" onclick="process_vocabulary()" style="font-size: 24px; padding: 10px 20px;  margin: 10px">Finish</button>');
        }
    }

    function back_vocabulary() {
        count--;
        if (count >= 0) {
            word = words[count];
            $('#vocabulary').html('<div style="font-size: 35px;">' + words[count].mean + ' ('+ words[count].type + '):' + '</div>' +
            '<input id="word" placeholder="Nhập từ" required style="font-size: 30px; border: 2px solid #333; padding: 10px; width: 300px; margin: 10px; font-weight: bold; color: ' + (words[count].status === 0 ? 'red' : (words[count].status === 1 ? 'green' : 'black')) + ';">' +
            '<button type="button" onclick="submit()" style="font-size: 24px; padding: 10px 20px;">Submit</button>');
            
            if (words[count].temporary != "") {
                $('#word').val(words[count].temporary);
            }
        } else {
            count = 0;
        }   
    }

    function submit() {
        var userInput = $('#word').val().trim().toLowerCase();
        words[count]['temporary'] = userInput;
        if (words[count].word == userInput) {
            $('#word').css('color', 'green');
            words[count]['status'] = 1;
            setTimeout(function() {
                next_vocabulary();
            }, 1000);
        } else {
            $('#word').css('color', 'red');
            words[count]['status'] = 0;
        }
    }

    function process_vocabulary() {
        $.ajax({
            url: '/vocabulary/process/vocabulary.php',
            method: 'POST',
            data: {type: 'word', words: words},
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    alert(data.message);
                } else {
                    alert(data.message);
                }
            },
            error: function(error) {
                console.error('Lỗi:', error);
            }
        });

        $('.learn').hide();
        
        $('#vocabulary').html('<div id="finish" style="font-size: 30px;">Bạn đã hoàn thành words ngày hôm nay </div><div style="display: flex; flex-direction: column;"></div>');
        words.forEach(function(word) {
            if (word.status == 1 || word.status == 0) {
                $('#finish').append('<div style="font-size: 30px; color: ' + (word.status === 0 ? 'red' : (word.status === 1 ? 'green' : 'black')) + ';">' + word.word + ' (' + word.type + '): ' + word.mean + '</div>');
            }
        });
    }


</script>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/footer.php';?>