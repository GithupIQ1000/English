<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/includes/functions.js"></script>
</head>
<body>
<div class="container" style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh;">
    <form id="login-form" class="form" method="POST"
    style="display: flex; flex-direction: column; width: 300px; gap: 10px; margin-bottom: 20px;">
        <h3>Đăng nhập</h3>
        <input type="text" name="username" placeholder="Tên đăng nhập" required>
        <input type="password" name="password" placeholder="Mật khẩu" required>
        <button type="submit">Đăng nhập</button>
    </form>

    <form id="register-form" class="form" method="POST"
    style="display: flex; flex-direction: column; width: 300px; gap: 10px; margin-bottom: 20px;">
        <h3>Đăng ký</h3>
        <input type="text" name="nickname" placeholder="Biệt danh">
        <input type="text" name="username" placeholder="Tên đăng nhập" required>
        <input type="password" name="password" placeholder="Mật khẩu" required>
        <button type="submit">Đăng ký</button>
    </form>

    <div class="form-toggle">
        <button id="show-login">Đăng nhập</button>
        <button id="show-register">Đăng ký</button>
    </div>

    <div id="message" style="margin-top: 10px; color: green;"></div>
</div>

<script>
    showLogin();
    
    function showLogin() {
        $('#login-form').show();
        $('#register-form').hide();
    }

    function showRegister() {
        $('#register-form').show();
        $('#login-form').hide();
    }

    $('#show-login').click(showLogin);
    $('#show-register').click(showRegister);


    $('#login-form').on('submit', function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: '/vocabulary/accounts/login.php',
            data: formData,
            dataType: 'json',
            success: function(data) {
                $('#message').css('color', data.success ? 'green' : 'red').html(`<div id="3s_hide">${data.message}</div>`);
                if (data.success) {
                    window.location.assign('/vocabulary/index.php');
                }
                hideMessageAfterDelay();
            },
            error: function(err) {
                console.error('Lỗi khi đăng nhập:', err);
                $('#message').css('color', 'red').html(`<div id="3s_hide">Lỗi máy chủ.</div>`);
                hideMessageAfterDelay();
            }
        });
    });

    $('#register-form').on('submit', function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: '/vocabulary/accounts/register.php',
            data: formData,
            dataType: 'json',
            success: function(data) {
                $('#message').css('color', data.success ? 'green' : 'red').html(`<div id="3s_hide">${data.message}</div>`);
                if (data.success) {
                    $('#register-form')[0].reset();
                    showLogin();
                }
                hideMessageAfterDelay();
            },
            error: function(err) {
                console.error('Lỗi khi đăng nhập:', err);
                $('#message').css('color', 'red').html(`<div id="3s_hide">Lỗi máy chủ.</div>`);
                hideMessageAfterDelay();
            }
        });
    });
</script>
</body>
</html>