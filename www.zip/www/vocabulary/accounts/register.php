<?php
include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/config/database.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $nickname = trim($_POST['nickname']);

    if (empty($username) || empty($password) || empty($nickname)) {
        echo json_encode(["success" => false, "message" => "Vui lòng nhập đầy đủ tên đăng nhập, mật khẩu và biệt danh."]);
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $count = $stmt->fetchColumn();

            if ($count > 0) {
                echo json_encode(["success" => false, "message" => "Tên đăng nhập đã tồn tại."]);
            } else {
                $stmt1 = $pdo->prepare("INSERT INTO users (username, password, nickname, point_jump_word, point_jump_meaning, point_jump_reading, point_jump_speaking, Nx_points) VALUES (?, ?, ?, 1, 1, 1, 1, 1.5)");
                $stmt2 = $pdo->prepare("INSERT INTO users_convenience (blank_check_word, blank_check_meaning, blank_check_reading, blank_check_speaking, host) VALUES (1, 1, 1, 1, ?)");

                $success1 = $stmt1->execute([$username, $hashed, $nickname]);
                $success2 = $stmt2->execute([$username]);

                if ($success1 && $success2) {
                    echo json_encode(["success" => true, "message" => "Đăng ký thành công!"]);
                } else if (!$success1) {
                    echo json_encode(["success" => false, "message" => "Lỗi khi đăng ký tài khoản."]);
                } else if (!$success2) {
                    echo json_encode(["success" => false, "message" => "Lỗi khi đăng ký tiện ích tài khoản."]);
                }
            }
        } catch (PDOException $e) {
            echo json_encode(["success" => false, "message" => "Lỗi: " . $e->getMessage()]);
        }
    }
}
?>
