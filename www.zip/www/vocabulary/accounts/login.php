<?php
include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/functions.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    try {
        $stmt = $pdo->prepare("SELECT password, nickname FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = [
                'username' => $username,
                'nickname' => $user['nickname']
            ];
            echo json_encode(["success" => true, "message" => "Đăng nhập thành công!"]);
            exit;
        } else {
            echo json_encode(["success" => false, "message" => "Sai tên đăng nhập hoặc mật khẩu."]);
            exit;
        }
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Lỗi máy chủ: " . $e->getMessage()]);
        exit;
    }
}
?>
