<?php
session_start();

// 1. Xóa tất cả các biến session
// session_unset() loại bỏ tất cả các biến đã đăng ký trong session hiện tại.
session_unset();

// 2. Hủy session
// session_destroy() phá hủy tất cả dữ liệu được liên kết với session hiện tại.
// Thao tác này không xóa biến session trong $_SESSION, nhưng nó sẽ xóa dữ liệu phiên
// khỏi bộ nhớ của máy chủ và vô hiệu hóa session ID.
session_destroy();

// 3. (Tùy chọn) Xóa cookie session khỏi trình duyệt
// Điều này đảm bảo rằng session ID không còn tồn tại trong trình duyệt của người dùng.
// Nó đặc biệt hữu ích để tránh người dùng quay lại bằng cách sử dụng session ID cũ.
// setcookie(session_name(), '', time() - 3600, '/');
// Đoạn mã trên sẽ đặt thời gian hết hạn của cookie session (có tên là session_name())
// về quá khứ, khiến trình duyệt xóa nó ngay lập tức.
// Tham số cuối cùng '/' đảm bảo cookie được xóa trên toàn bộ miền.

// 4. Chuyển hướng người dùng về trang đăng nhập hoặc trang chính
// Đảm bảo không có bất kỳ đầu ra nào (khoảng trắng, HTML) trước dòng header().
header("Location: /vocabulary/accounts/index.php"); // Thay /login.php bằng trang bạn muốn chuyển hướng đến

exit(); // Quan trọng: Dừng việc thực thi script sau khi chuyển hướng
?>