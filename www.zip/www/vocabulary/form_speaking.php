<?php include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/header.php';?>
<div style="display: flex; flex-direction: column; gap: 10px; align-items: center; justify-content: center; height: 100vh;">
    <div id="speaking" style="display: flex; align-items: center; justify-content: center;"></div>
    <div id="translate" style="display: flex; flex-direction: column; align-items: center; justify-content: center;"></div>
    <div style="display: flex; gap: 10px; justify-content: center;">
        <button class="learn" type="button" onclick="nextSpeaking()" style="font-size: 24px; padding: 10px 20px;">Next</button>
        <button class="learn" type="button" onclick="backSpeaking()" style="font-size: 24px; padding: 10px 20px;">Back</button>
    </div>
    <button 
        onclick="if(confirm('Bạn có chắc chắn muốn quay lại trang chủ?')) { window.location.href='/vocabulary/index.php'; } else { alert('Hành động đã bị hủy bỏ!'); }" 
        style="font-size: 24px; padding: 10px 20px; margin-top: 10px;">Quay lại
    </button>
</div>
<script>
    $(document).ready(function() {
        takeVocabulary();
    });

    function takeVocabulary() {
        $.ajax({
            url: '/vocabulary/process/vocabulary.php',
            method: 'POST',
            data: {type: 'speaking'},
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    if (data.message.length > 0) {
                        count = -1;
                        end_count = data.message.length;
                        words = data.message;
                        alert("Dữ liệu OK");
                        request_AI();
                    } else {
                        $('.learn').hide();
                        $('#speaking').html('<div style="font-size: 30px;">Hôm nay không có speaking nào.</div>');
                    }
                } else {
                    alert(data.message);
                }
            },
            error: function(error) {
                console.error('Lỗi:', error);
            }
        });
    }
    
    function requestAI() {
        var api_key = "AIzaSyB1jQP2jxowOUKiuvTGGAqlzqGK_-ZoiFA";
        
        var prompt = "Từ những từ sau: " + words.map(function(word) {
            return word.word + "(" + word.type + "): " + word.mean;
        }).join(", ") + ". Hãy tạo một câu tiếng Anh chứa mỗi từ đó, rồi dịch sang tiếng Việt. Trả về kết quả dưới dạng JSON bám theo các từ và cấu trúc của dữ liệu đầu vào như sau:\n";
        
        prompt += "Câu phải mang nghĩa hợp lý và thay đổi câu liên tục random. Chỉ trả về JSON thuần (KHÔNG được trả lời gì khác ngoài JSON. KHÔNG markdown).\n";
        prompt += "Định dạng chính xác như sau:\n";
        prompt += '{ "access(n/v): sự truy cập/truy cập": ["Nghĩa tiếng Việt", "Câu tiếng Anh"], "access(n): lối vào": ["...", "..."], ... }';
        

        var url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + api_key;

        var data = {
            "contents": [
                {
                    "parts": [
                        { "text": prompt }
                    ]
                }
            ]
        };

        $.ajax({
            url: url,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(data),
            success: function (response) {
                try {
                    console.log("📨 Phản hồi thô từ Gemini:", response);
                    var rawText = response.candidates?.[0]?.content?.parts?.[0]?.text || "";

                    // ✅ Làm sạch markdown hoặc nội dung phụ nếu có
                    rawText = rawText.trim();
                    rawText = rawText.replace(/^```(json)?\s*/i, "");   // bỏ đầu ```json
                    rawText = rawText.replace(/\s*```$/g, "");          // bỏ cuối ```
                    
                    // ✅ Nếu Gemini vẫn thêm văn bản → cắt phần bắt đầu từ dấu `{`
                    let firstCurly = rawText.indexOf('{');
                    if (firstCurly !== -1) {
                        rawText = rawText.slice(firstCurly);
                    }

                    // ✅ Parse JSON
                    sentences = JSON.parse(rawText);
                    console.log("✅ JSON sạch từ Gemini:", sentences);
                    nextSpeaking();
                } catch (e) {
                    console.error("❌ Lỗi xử lý JSON:", e);
                    alert("Gemini trả về định dạng không đúng JSON.");
                }
            },
            error: function (err) {
                console.error("❌ Lỗi gửi request:", err);
                alert("Lỗi khi gọi API Gemini.");
            }
        });
    }

    function nextSpeaking() {
        count++;
        if (count < end_count) {
            var key = words[count].word + "(" + words[count].type + "): " + words[count].mean;

            if (typeof words[count]['status'] == 'undefined') {
                words[count]['status'] = -1;
            }
            if (words[count]['status'] == -1) { 
                words[count]['Nx_points'] = 0;
                $('#translate').html('<button type="button" onclick="Nx_points()" style="font-size: 24px; padding: 10px 20px;">x N_point</button>');
            } else {
                $('#translate').html(`
                    <div style="display: flex; gap: 10px; align-items: center; justify-content: center;">
                        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center;">
                            <div id="sentence" style="font-size: 30px;">${sentences[key][1]}</div>
                            <div style="font-size: 30px;">${words[count].word} (${words[count].type}): ${words[count].mean}</div>
                        </div>
                        <div style="display: flex; gap: 10px; justify-content: center;">
                            <button type="button" onclick="mark(1)" style="font-size: 24px; padding: 10px 20px;">Ok</button>
                            <button type="button" onclick="mark(0)" style="font-size: 24px; padding: 10px 20px;">Forget</button>
                        </div>
                    </div>
                `);
            } 
            $('#speaking').html('<div id="sentence" style="font-size: 35px; color: ' + (words[count].status === 0 ? 'red' : (words[count].status === 1 ? 'green' : 'black')) + '; padding: 10px;">' + (sentences?.[key]?.[0] || words[count].word + ' [Câu chưa sẵn sàng]') + '</div>' +
            '<button type="button" onclick="translate_sentence()" style="font-size: 24px; padding: 10px 20px;">Translate</button>');
        } else {
            count = end_count;
            $('#speaking').html('<div style="font-size: 30px;">Bạn đã hoàn thành speakings ngày hôm nay </div>' +
            '<button type="button" onclick="saveVocabulary()" style="font-size: 24px; padding: 10px 20px;  margin: 10px">Finish</button>');
            $('#translate').html('');
        }
    }

    function backSpeaking() {
        count--;
        if (count >= 0) {
            var key = words[count].word + "(" + words[count].type + "): " + words[count].mean;4

            if (words[count]['status'] == -1) {
                words[count]['Nx_points'] = 0;
                $('#translate').html('<button type="button" onclick="Nx_points()" style="font-size: 24px; padding: 10px 20px;">x N_point</button>');
            } else {
                $('#translate').html(`
                    <div style="display: flex; gap: 10px; align-items: center; justify-content: center;">
                        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center;">
                            <div id="sentence" style="font-size: 30px;">${sentences[key][1]}</div>
                            <div style="font-size: 30px;">${words[count].word} (${words[count].type}): ${words[count].mean}</div>
                        </div>
                        <div style="display: flex; gap: 10px; justify-content: center;">
                            <button type="button" onclick="mark(1)" style="font-size: 24px; padding: 10px 20px;">Ok</button>
                            <button type="button" onclick="mark(0)" style="font-size: 24px; padding: 10px 20px;">Forget</button>
                        </div>
                    </div>
                `);
            }            
            $('#speaking').html('<div id="sentence" style="font-size: 35px; color: ' + (words[count].status === 0 ? 'red' : (words[count].status === 1 ? 'green' : 'black')) + '; padding: 10px;">' + (sentences?.[key]?.[0] || words[count].word + ' [Câu chưa sẵn sàng]') + '</div>' +
            '<button type="button" onclick="translate_sentence()" style="font-size: 24px; padding: 10px 20px;">Translate</button>');
        } else {
            count = 0;
        }   
    }

    function Nx_points() {
        words[count]['Nx_points'] = 1;
        $('#translate').html('');
    }

    function translate_sentence() {
        if ($('#translate').html() === '' || $('#translate').html() ==='<button type="button" onclick="Nx_points()" style="font-size: 24px; padding: 10px 20px;">x N_point</button>') {
            var key = words[count].word + "(" + words[count].type + "): " + words[count].mean;
            $('#translate').html(`
                <div style="display: flex; gap: 10px; align-items: center; justify-content: center;">
                    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center;">
                        <div id="sentence" style="font-size: 30px;">${sentences[key][1]}</div>
                        <div style="font-size: 30px;">${words[count].word} (${words[count].type}): ${words[count].mean}</div>
                    </div>
                    <div style="display: flex; gap: 10px; justify-content: center;">
                        <button type="button" onclick="mark(1)" style="font-size: 24px; padding: 10px 20px;">Ok</button>
                        <button type="button" onclick="mark(0)" style="font-size: 24px; padding: 10px 20px;">Forget</button>
                    </div>
                </div>
            `);
        }else{
            $('#translate').html('');
        }
    }

    function mark(status) {
        words[count]['status'] = status;
        if (status) {
            $('#sentence').css('color', 'green');
            setTimeout(function() {
                nextSpeaking();
            }, 1000);
        } else {
            $('#sentence').css('color', 'red');
        }
    }

    function saveVocabulary() {
        $.ajax({
            url: '/vocabulary/process/vocabulary.php',
            method: 'POST',
            data: {type: 'speaking', words: words},
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    alert(data.message);
                } else {
                    alert(data.message);
                }
            },
            error: function(error) {
                console.error('Lỗi:', error);
            }
        });

        $('.learn').hide();
        
        $('#speaking').html('<div id="finish" style="font-size: 30px; max-height: 80vh; overflow-y: auto; padding: 10px; background-color: #fff; border-radius: 8px;">Bạn đã hoàn thành speakings ngày hôm nay </div>');
        $('#translate').html('');
        words.forEach(function(word) {
            if (word.status == 1 || word.status == 0) {
                $('#finish').append('<div style="font-size: 30px; color: ' + (word.status === 0 ? 'red' : (word.status === 1 ? 'green' : 'black')) + ';">' + word.word + ' (' + word.type + '): ' + word.mean + '</div>');
            }
        });
    }
</script>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/footer.php';?>
