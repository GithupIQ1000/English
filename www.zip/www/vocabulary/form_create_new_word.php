<?php 
include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/header.php';

$stmt = $pdo->prepare("SELECT blank_check_word, blank_check_reading, blank_check_speaking FROM users_convenience WHERE host = ?");
$stmt->execute([$_SESSION['user']['username']]);
$blanks = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh;">
    <form id="newWordForm" onsubmit="createNewWord(event)" style="text-align: center;"
    style="display: flex; flex-direction: column; width: 300px; gap: 10px;">
        <div>
            <input type="text" name="new-word" placeholder="Từ mới" required style="font-size: 24px; border: 2px solid #333; padding: 10px; width: 300px; margin-bottom: 10px;">
            <input type="text" name="type" placeholder="Loại" required style="font-size: 24px; border: 2px solid #333; padding: 10px; width: 100px; margin-bottom: 10px;">
            <input type="text" name="mean" placeholder="Nghĩa" required style="font-size: 24px; border: 2px solid #333; padding: 10px; width: 300px; margin-bottom: 10px;">
            <button type="submit" style="font-size: 24px; padding: 10px 20px;">Tạo</button>
        </div>
        <div style="display: flex; flex-direction: row; align-items: center; justify-content: center; gap: 100px;">
            <div style="display: flex; flex-direction: column; gap: 10px; font-size: 20px;">
                <input type="checkbox" name="check-word" value="1" style="transform: scale(1.5);">
                Kiểm tra từ
            </div>
            <div style="display: flex; flex-direction: column; gap: 10px; font-size: 20px;">
                <input type="checkbox" name="check-reading" value="1" style="transform: scale(1.5);">
                Kiểm tra đọc
            </div>    
            <div style="display: flex; flex-direction: column; gap: 10px; font-size: 20px;">
                <input type="checkbox" name="check-speaking" value="1" style="transform: scale(1.5);">
                Kiểm tra nói
            </div>    
        </div>
    </form>
    <div id="message" style="font-size: 24px"></div>
    <button onclick="window.location.href='/vocabulary/index.php'" style="font-size: 24px; padding: 10px 20px; margin-top: 10px; font-size: 24px">Quay lại</button>
</div>
<script>
    $(document).ready(function() {
        takeVocabulary();
    });

    function takeVocabulary() {
        $.ajax({
            url: '/vocabulary/process/setting.php',
            method: 'POST',
            data: {type: 'blank'},
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    blanks = data.message;
                    if (blanks.blank_check_word == 1) {
                        $("input[name='check-word']").prop('checked', true);
                    }
                    if (blanks.blank_check_reading == 1) {
                        $("input[name='check-reading']").prop('checked', true);
                    }
                    if (blanks.blank_check_speaking == 1) {
                        $("input[name='check-speaking']").prop('checked', true);
                    }
                } else {
                    alert(data.message);
                }
            },
            error: function(error) {
                console.error('Lỗi:', error);
            }
        });
    }

    function createNewWord(event) {
        event.preventDefault();
        var formData = $('#newWordForm').serialize();
        $.ajax({
            type: 'POST',
            url: '/vocabulary/process/create_new_word.php',
            data: formData,
            success: function(data) {
                $('#message').html(data.message);
                $('#newWordForm')[0].reset();
                setTimeout(function() {
                    var element = document.getElementById("3s_hide");
                    if (element) {
                        element.style.transition = "opacity 1s ease"; // Thêm hiệu ứng chuyển tiếp
                        element.style.opacity = 0; // Đặt độ mờ về 0
                        setTimeout(function() {
                            element.style.display = "none"; // Ẩn phần tử sau khi chuyển tiếp
                        }, 1000); // Thời gian trễ để ẩn phần tử
                    }
                }, 3000);
            },
            error: function(error) {
                console.error('Lỗi:', error);
            }
        });
    }
</script>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/vocabulary/includes/footer.php';?>