with open(r'D:\xxx.txt', 'r', encoding='utf-8') as f:
    sum = []
    i=0
    for a in f:
        i+=1
        if i==1: continue
        if a.strip() and a.strip()[0]=='"':
            # print(a.strip()[0])
            # print(a.strip())
            array = list(a.split('"'))
            sum.append(array[1])
with open(r'D:\x.txt', 'w', encoding='utf-8') as f:
    for i in sum:
        f.write(i + '\n')
