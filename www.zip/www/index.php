<?php
header("Location: /vocabulary/index.php");
exit;
?>